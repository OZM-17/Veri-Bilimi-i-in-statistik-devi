"""
ab_testing_utils.py
===================
A/B Testing için yardımcı fonksiyonlar.
Notebook'ta `from src.ab_testing_utils import *` ile kullanılır.
"""

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# ── Renk Paleti ──────────────────────────────────────────────
COLORS = {
    "A":       "#185FA5",
    "B":       "#0F6E56",
    "accent":  "#D85A30",
    "bg":      "#F8F7F4",
    "card":    "#FFFFFF",
    "muted":   "#888780",
    "success": "#3B6D11",
    "warn":    "#BA7517",
    "fail":    "#A32D2D",
}

plt.rcParams.update({
    "font.family":       "DejaVu Sans",
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "axes.facecolor":    COLORS["bg"],
    "figure.facecolor":  COLORS["bg"],
    "axes.labelsize":    11,
    "xtick.labelsize":   10,
    "ytick.labelsize":   10,
})


# ── İstatistiksel Fonksiyonlar ───────────────────────────────

def conversion_rate(df, group_col, metric_col, gA_val, gB_val):
    """
    İki grup için conversion rate ve temel istatistikler döndürür.

    Parametreler
    ------------
    df         : pd.DataFrame
    group_col  : grup kolonu adı
    metric_col : başarı/başarısızlık kolonu (0/1)
    gA_val     : Grup A değeri (str)
    gB_val     : Grup B değeri (str)

    Döndürür
    --------
    dict: nA, nB, kA, kB, pA, pB, liftPct
    """
    grA = df[df[group_col] == gA_val]
    grB = df[df[group_col] == gB_val]
    nA, nB = len(grA), len(grB)
    kA     = int(grA[metric_col].sum())
    kB     = int(grB[metric_col].sum())
    pA, pB = kA / nA, kB / nB
    return dict(
        nA=nA, nB=nB, kA=kA, kB=kB,
        pA=pA, pB=pB,
        liftPct=round((pB - pA) / pA * 100, 4),
    )


def binom_stats(p, n):
    """
    Binom dağılımı istatistikleri.

    Döndürür: (E[X], Var(X), σ)
    Formüller: E[X]=np, Var(X)=np(1-p), σ=√Var
    """
    mean = n * p
    var  = n * p * (1 - p)
    return mean, var, np.sqrt(var)


def confidence_interval(p, n, alpha=0.05):
    """
    Wald yöntemi ile güven aralığı.

    CI = p̂ ± z_{α/2} · √(p̂(1-p̂)/n)
    Varsayılan: %95 (alpha=0.05)
    """
    z_crit = stats.norm.ppf(1 - alpha / 2)          # 1.96
    margin = z_crit * np.sqrt(p * (1 - p) / n)
    return p - margin, p + margin


def z_test_two_proportions(kA, nA, kB, nB):
    """
    İki oran için Pooled Z-testi.

    H₀: p_A = p_B
    H₁: p_A ≠ p_B  (iki yönlü)

    Döndürür: (z_istatistigi, p_degeri)
    """
    pA, pB  = kA / nA, kB / nB
    p_pool  = (kA + kB) / (nA + nB)
    se      = np.sqrt(p_pool * (1 - p_pool) * (1/nA + 1/nB))
    z       = (pA - pB) / se
    p_val   = 2 * (1 - stats.norm.cdf(abs(z)))
    return z, p_val


def power_analysis(pA, pB, alpha=0.05, power=0.80):
    """
    Minimum gerekli örneklem büyüklüğü (her grup için).

    Formül: n = (z_α/2 + z_β)² · 2p̄(1-p̄) / (pA-pB)²
    """
    effect  = abs(pB - pA)
    z_alpha = stats.norm.ppf(1 - alpha / 2)
    z_beta  = stats.norm.ppf(power)
    p_bar   = (pA + pB) / 2
    n = ((z_alpha + z_beta)**2 * 2 * p_bar * (1 - p_bar)) / effect**2
    return int(np.ceil(n))


def binom_pmf_array(n, p, radius=60):
    """Binom PMF dizisi — grafik için."""
    mu     = int(round(n * p))
    k_vals = np.arange(max(0, mu - radius), min(n, mu + radius) + 1)
    return k_vals, stats.binom.pmf(k_vals, n, p)


# ── Görselleştirme Fonksiyonları ─────────────────────────────

def plot_ab_analysis(st, z, p_val, ciA, ciB, title, save_path=None):
    """
    Tek veri seti için 3-panel grafik.

    Panel 1 : Conversion Rate bar chart
    Panel 2 : 95% Güven Aralıkları
    Panel 3 : Binom Dağılımı (PMF)
    """
    sig         = p_val < 0.05
    label_color = COLORS["success"] if sig else COLORS["fail"]

    fig, (ax_bar, ax_ci, ax_binom) = plt.subplots(
        1, 3, figsize=(15, 4), facecolor=COLORS["bg"])
    fig.suptitle(title, fontsize=12, fontweight="500", y=1.02)

    # ── Panel 1: Bar Chart ──────────────────────────────────
    rates = [st["pA"] * 100, st["pB"] * 100]
    bars  = ax_bar.bar(["Grup A", "Grup B"], rates,
                       color=[COLORS["A"], COLORS["B"]],
                       width=0.45, zorder=3, edgecolor="white", linewidth=1.5)
    for bar, rate in zip(bars, rates):
        ax_bar.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.05,
                    f"{rate:.2f}%", ha="center", va="bottom",
                    fontsize=10, fontweight="500")
    verdict = f"p = {p_val:.4f}  →  {'Anlamlı ✓' if sig else 'Anlamsız ✗'}"
    ax_bar.text(0.5, 0.97, verdict, transform=ax_bar.transAxes,
                ha="center", va="top", fontsize=9, color=label_color,
                bbox=dict(boxstyle="round,pad=0.3",
                          fc=COLORS["card"], ec=label_color, lw=1.2))
    ax_bar.set_title("Conversion Rate", fontsize=10, fontweight="500")
    ax_bar.set_ylabel("Rate (%)")
    ax_bar.yaxis.set_major_formatter(
        plt.FuncFormatter(lambda x, _: f"{x:.1f}%"))
    ax_bar.set_ylim(0, max(rates) * 1.30)
    ax_bar.grid(axis="y", alpha=0.3, zorder=0)

    # ── Panel 2: Güven Aralıkları ───────────────────────────
    for i, (pv, ci, col) in enumerate(
            [(st["pA"], ciA, COLORS["A"]),
             (st["pB"], ciB, COLORS["B"])]):
        ax_ci.errorbar(pv * 100, i,
                       xerr=[[( pv - ci[0]) * 100],
                              [(ci[1] - pv)  * 100]],
                       fmt="o", color=col, capsize=9, capthick=2,
                       elinewidth=2.5, markersize=9, zorder=4)
        ax_ci.text(pv * 100, i + 0.18, f"{pv:.3%}",
                   ha="center", fontsize=9, color=col, fontweight="500")
    ax_ci.set_yticks([0, 1])
    ax_ci.set_yticklabels(["Grup B", "Grup A"])
    ax_ci.set_title("95% Güven Aralıkları", fontsize=10, fontweight="500")
    ax_ci.set_xlabel("Rate (%)")
    ax_ci.xaxis.set_major_formatter(
        plt.FuncFormatter(lambda x, _: f"{x:.1f}%"))
    ax_ci.set_ylim(-0.6, 1.6)
    ax_ci.grid(axis="x", alpha=0.3)

    # ── Panel 3: Binom Dağılımı ─────────────────────────────
    n_s = min(st["nA"], 5000)
    kA, pmfA = binom_pmf_array(n_s, st["pA"], radius=55)
    kB, pmfB = binom_pmf_array(n_s, st["pB"], radius=55)
    ax_binom.fill_between(kA, pmfA * 100, alpha=0.4,
                          color=COLORS["A"], label="Grup A")
    ax_binom.fill_between(kB, pmfB * 100, alpha=0.4,
                          color=COLORS["B"], label="Grup B")
    ax_binom.plot(kA, pmfA * 100, color=COLORS["A"], linewidth=2)
    ax_binom.plot(kB, pmfB * 100, color=COLORS["B"], linewidth=2)
    ax_binom.axvline(st["pA"] * n_s, color=COLORS["A"], ls="--", alpha=0.7)
    ax_binom.axvline(st["pB"] * n_s, color=COLORS["B"], ls="--", alpha=0.7)
    ax_binom.set_title(f"Binom Dağılımı (n={n_s:,})",
                       fontsize=10, fontweight="500")
    ax_binom.set_xlabel("Başarı Sayısı (k)")
    ax_binom.set_ylabel("P(X=k) ×100")
    ax_binom.legend(fontsize=9, framealpha=0.6)
    ax_binom.grid(axis="y", alpha=0.3)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor=COLORS["bg"])
    plt.show()


def print_analysis_summary(title, st, z, p_val, ciA, ciB,
                            meanA, varA, stdA, meanB, varB, stdB, n_req):
    """Analiz sonuçlarını düzenli biçimde yazdırır."""
    sep = "=" * 60
    sig = p_val < 0.05
    print(f"\n{sep}\n  {title}\n{sep}")
    print(f"\n{'GRUP':>10} {'n':>8} {'Converted':>10} {'Rate':>8}")
    print("-" * 42)
    print(f"{'A':>10} {st['nA']:>8,} {st['kA']:>10,} {st['pA']:>8.4%}")
    print(f"{'B':>10} {st['nB']:>8,} {st['kB']:>10,} {st['pB']:>8.4%}")
    print(f"\n📊 Binom — Grup A: E[X]={meanA:,.2f} | Var(X)={varA:,.2f} | σ={stdA:,.2f}")
    print(f"📊 Binom — Grup B: E[X]={meanB:,.2f} | Var(X)={varB:,.2f} | σ={stdB:,.2f}")
    print(f"\n🔬 Hipotez Testi (H₀: p_A = p_B)")
    print(f"   Z = {z:+.4f}  |  p = {p_val:.6f}  |  α = 0.05")
    print(f"   → {'H₀ REDDEDİLDİ ✓' if sig else 'H₀ REDDEDİLEMEDİ ✗'}")
    print(f"\n📏 95% CI  A: [{ciA[0]:.4%} — {ciA[1]:.4%}]")
    print(f"           B: [{ciB[0]:.4%} — {ciB[1]:.4%}]")
    print(f"\n💡 Lift: {st['liftPct']:+.2f}%  |  Min örneklem: {n_req:,}/grup")
    if sig:
        winner = "B" if st["pB"] > st["pA"] else "A"
        print(f"   ✅ Grup {winner} daha başarılı → Değişiklik önerilir.")
    else:
        print("   ⚠️  Anlamlı fark yok → Mevcut versiyonu koru.")
