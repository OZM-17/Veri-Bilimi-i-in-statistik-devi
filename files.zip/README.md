# 📊 A/B Testing ve Conversion Rate Analizi

> **Olasılık ve İstatistik Dersi — Proje 1**  
> Teslim Tarihi: 15.05.2026

---

## 📁 Proje Yapısı

```
ab_testing_project/
│
├── notebooks/
│   └── ab_testing_analizi.ipynb   ← Ana Jupyter Notebook
│
├── src/
│   └── ab_testing_utils.py        ← Yardımcı fonksiyonlar (modüler)
│
├── data/
│   ├── ab_data.csv                ← Dataset 1A (Kaggle'dan indirilecek)
│   ├── cookie_cats.csv            ← Dataset 1B (Kaggle'dan indirilecek)
│   └── marketing_AB_testing.csv   ← Dataset 1C (Kaggle'dan indirilecek)
│
├── figures/                       ← Otomatik kaydedilen grafikler
│
├── requirements.txt
└── README.md
```

---

## 🎯 Proje Özeti

İki farklı uygulama versiyonunun (A ve B) kullanıcı davranışları üzerindeki etkisini
istatistiksel olarak analiz eden proje. Üç farklı gerçek dünya veri seti kullanılmıştır.

| Veri Seti | Konu | n | Metrik |
|-----------|------|---|--------|
| **1A** Website Button | Landing page A/B testi | ~300K | Conversion Rate |
| **1B** Mobile App | Cookie Cats oyun seviyesi | ~90K | 7-gün Retention |
| **1C** Marketing | Reklam vs PSA | ~588 | Satın Alma Oranı |

---

## 🔬 Uygulanan Kavramlar

- **Bernoulli Dağılımı** — Her kullanıcı: başarı (1) veya başarısızlık (0)
- **Binom Dağılımı** — n denemede k başarı; E[X] = np, Var(X) = np(1−p)
- **İki Oran Z-Testi** — H₀: p_A = p_B (pooled, iki yönlü)
- **Güven Aralıkları** — Wald yöntemi, %95 CI
- **p-değeri Yorumlama** — α = 0.05 eşiği
- **Güç Analizi** — Minimum örneklem büyüklüğü hesabı

---

## 🚀 Kurulum ve Çalıştırma

### 1. Repoyu klonla
```bash
git clone https://github.com/KULLANICI_ADIN/ab-testing-project.git
cd ab-testing-project
```

### 2. Sanal ortam oluştur (önerilir)
```bash
python -m venv venv

# Windows:
venv\Scripts\activate

# Mac/Linux:
source venv/bin/activate
```

### 3. Bağımlılıkları yükle
```bash
pip install -r requirements.txt
```

### 4. Veri setlerini indir
Kaggle'dan aşağıdaki veri setlerini indirip `data/` klasörüne koy:

| Dosya Adı | Kaggle Linki |
|-----------|-------------|
| `ab_data.csv` | [AB Test Dataset](https://www.kaggle.com/datasets/zhangluyuan/ab-testing) |
| `cookie_cats.csv` | [Mobile Games AB Testing](https://www.kaggle.com/datasets/yufengsui/mobile-games-ab-testing) |
| `marketing_AB_testing.csv` | [Marketing AB Testing](https://www.kaggle.com/datasets/faviovaz/marketing-ab-testing) |

> ⚠️ Veri setleri büyük olduğu için `.gitignore` ile repo'ya dahil edilmemiştir.

### 5. Jupyter Notebook'u çalıştır
```bash
jupyter notebook notebooks/ab_testing_analizi.ipynb
```

---

## 📊 Sonuçlar

| Veri Seti | p_A | p_B | Lift | p-değeri | Karar |
|-----------|-----|-----|------|----------|-------|
| 1A Website | 11.88% | 11.73% | −1.26% | 0.1933 | ❌ Anlamlı fark yok |
| 1B Mobile App | 44.82% | 44.23% | −1.32% | 0.0175 | ✅ gate_30 daha iyi |
| 1C Marketing | 9.79% | 14.45% | +47.6% | 0.0042 | ✅ Reklam daha etkili |

---

## 🛠️ Kullanılan Kütüphaneler

```
numpy · pandas · scipy · matplotlib
```

---

## 📄 Lisans

MIT License — Eğitim amaçlı kullanım serbesttir.
